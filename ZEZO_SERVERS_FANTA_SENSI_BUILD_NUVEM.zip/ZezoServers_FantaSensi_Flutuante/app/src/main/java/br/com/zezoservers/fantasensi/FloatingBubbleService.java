package br.com.zezoservers.fantasensi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

public class FloatingBubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private boolean panelOpen = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private void createNotification() {
        String channel = "zezo_floating";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channel, "ZEZO SERVERS", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, channel) : new Notification.Builder(this);
        builder.setContentTitle("ZEZO SERVERS ativo")
            .setContentText("A bolha flutuante está disponível.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true);
        startForeground(41, builder.build());
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(3, Color.rgb(255, 140, 35));
        return d;
    }

    private void showBubble() {
        TextView b = new TextView(this);
        b.setText("Z");
        b.setTextColor(Color.WHITE);
        b.setTextSize(21);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(Color.rgb(30, 30, 30), 100));
        bubble = b;

        bubbleParams = new WindowManager.LayoutParams(58, 58, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = 18;
        bubbleParams.y = 220;
        wm.addView(bubble, bubbleParams);

        b.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = bubbleParams.x; startY = bubbleParams.y; moved = false; return true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = (int)(e.getRawX() - downX), dy = (int)(e.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > 8) moved = true;
                    bubbleParams.x = startX + dx; bubbleParams.y = startY + dy;
                    wm.updateViewLayout(bubble, bubbleParams); return true;
                } else if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) togglePanel();
                    return true;
                }
                return true;
            }
        });
    }

    private void togglePanel() {
        if (panelOpen) {
            if (panel != null) { wm.removeView(panel); panel = null; }
            panelOpen = false;
            return;
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackground(shape(Color.rgb(24, 24, 24), 22));

        LinearLayoutCompat header = new LinearLayoutCompat(this);
        header.setBackgroundColor(Color.rgb(30, 30, 30));
        TextView title = new TextView(this);
        title.setText("  FANTA SENSI");
        title.setTextColor(Color.rgb(255, 140, 35));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextSize(14);
        header.addView(title, new LinearLayoutCompat.LayoutParams(0, 46, 1));
        TextView close = new TextView(this);
        close.setText("−");
        close.setTextSize(24);
        close.setTextColor(Color.WHITE);
        close.setGravity(Gravity.CENTER);
        header.addView(close, new LinearLayoutCompat.LayoutParams(48, 46));
        root.addView(header, new FrameLayout.LayoutParams(-1, 46, Gravity.TOP));

        WebView web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.loadUrl("https://fluffy-stroopwafel-ff7e19.netlify.app/");
        FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(-1, -1);
        wp.topMargin = 46;
        root.addView(web, wp);
        close.setOnClickListener(v -> togglePanel());

        panel = root;
        panelParams = new WindowManager.LayoutParams(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.86),
            (int)(getResources().getDisplayMetrics().heightPixels * 0.62),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;
        wm.addView(panel, panelParams);
        panelOpen = true;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override public void onDestroy() {
        if (wm != null) {
            if (panel != null) wm.removeView(panel);
            if (bubble != null) wm.removeView(bubble);
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    // Minimal horizontal container to avoid an AndroidX dependency.
    private static class LinearLayoutCompat extends android.widget.LinearLayout {
        LinearLayoutCompat(android.content.Context c) { super(c); setOrientation(HORIZONTAL); }
    }
}
