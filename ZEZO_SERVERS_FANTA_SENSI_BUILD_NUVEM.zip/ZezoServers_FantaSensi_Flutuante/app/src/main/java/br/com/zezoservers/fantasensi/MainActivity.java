package br.com.zezoservers.fantasensi;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 701;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(20, 20, 20));

        TextView title = new TextView(this);
        title.setText("ZEZO SERVERS\nFANTA SENSI FLUTUANTE");
        title.setTextColor(Color.rgb(255, 140, 35));
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("\nAtive a permissão 'Sobrepor a outros apps'. Depois toque no botão para iniciar a bolha flutuante.");
        info.setTextColor(Color.WHITE);
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        root.addView(info);

        Button start = new Button(this);
        start.setText("ATIVAR BOLHA ZEZO");
        root.addView(start);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(permission, OVERLAY_REQUEST);
            } else {
                startBubble();
            }
        });

        Button open = new Button(this);
        open.setText("ABRIR FANTA SENSI");
        root.addView(open);
        open.setOnClickListener(v -> startActivity(new Intent(this, WebPanelActivity.class)));

        setContentView(root);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            startBubble();
        }
    }

    private void startBubble() {
        Intent service = new Intent(this, FloatingBubbleService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
        finish();
    }
}
