ZEZO SERVERS - FANTA SENSI FLUTUANTE

Este é o PROJETO-FONTE Android, não um APK já compilado.

O que faz:
- Abre o site https://fluffy-stroopwafel-ff7e19.netlify.app/
- Cria uma bolha "Z" arrastável sobre outros aplicativos.
- Ao tocar na bolha, abre/fecha uma janela com o site.
- A janela usa WebView e precisa de internet.
- O Android pede autorização "Sobrepor a outros apps".

COMO GERAR O APK PELO NAVEGADOR (SEM ANDROID STUDIO):
1. Entre em https://github.com/ e crie uma conta, se ainda não tiver.
2. Crie um repositório. Se quiser manter o código privado, escolha Private.
3. Envie os arquivos e pastas deste projeto para o repositório, mantendo a estrutura.
4. Abra a aba Actions do repositório.
5. Se aparecer um aviso para habilitar Actions, habilite.
6. Selecione "Gerar APK ZEZO SERVERS" e toque em "Run workflow".
7. Aguarde a execução terminar com sucesso.
8. Na página da execução, vá até Artifacts e baixe "ZEZO-SERVERS-FANTA-SENSI-APK".
9. Extraia o ZIP baixado para encontrar app-debug.apk.

O arquivo .github/workflows/gerar-apk.yml configura a compilação na nuvem.
A compilação usa Java 17, Gradle 8.9 e Android SDK 35.

LIMITAÇÕES:
- Este pacote é o código-fonte com configuração de compilação na nuvem; ainda não é o APK.
- A compilação precisa terminar com sucesso no GitHub Actions antes de existir um APK para baixar.
- O painel apenas exibe o site; não injeta comandos no Free Fire nem altera o jogo.
- O Android exige autorização "Sobrepor a outros apps" para a bolha.
- O site e o painel precisam de internet.
